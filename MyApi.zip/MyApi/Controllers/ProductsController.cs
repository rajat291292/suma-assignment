﻿using MyApi.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;

namespace MyApi.Controllers
{
    public class ProductsController : ApiController
    {
        // GET: Products
        List<ProductEntity> products = new List<ProductEntity>();

        public ProductsController ()
        {
          GetSampleProducts();
        }
        public IEnumerable<ProductEntity> Get()
        {
            return products;
        }

        public ProductEntity Get(int id)
        {
            var product = products.FirstOrDefault(c=>c.ProductId== id);
        return product;
    }
    private void GetSampleProducts()
    {
        products.Add(new ProductEntity() { ProductId = 1, Name = "apple", Description = "fresh green apple", price = 1.4M });
            products.Add(new ProductEntity() { ProductId = 2, Name = "Orange", Description = "fresh Orange ", price = 1.4M });
            products.Add(new ProductEntity() { ProductId = 3, Name = "BAnana", Description = "fresh BAnana", price = 1.6M });
            products.Add(new ProductEntity() { ProductId = 4, Name = "Grapes", Description = "fresh Grapes", price = 1.4M });


        }
    }
}